# YouTube Kids Channel Automation Bot

A comprehensive management and automation application designed specifically for YouTube Kids channel creators and studio owners.

## 🌟 Key Features

1. **Dashboard:** Live channel statistics, subscriber tracking, published video metrics, upcoming content deadlines, and production pipeline overview.
2. **AI Kids Content Generator:** Generates Montessori-aligned educational scripts, scene-by-scene storyboards, SEO titles, child-safe tags, and AI thumbnail prompts across customizable age groups (Toddlers 2-4, Preschool 4-6, Early Elementary 6-8, Tweens 9-12).
3. **Video Management & Owner Approval Gate:** Full video lifecycle management (`Draft` → `Scripted` → `In Production` → `Needs Review` → `Owner Approved` → `Scheduled` → `Published`). **Strict policy:** The channel owner must explicitly sign off on each video before publishing.
4. **Content Calendar:** Daily and weekly task planner with production checklists (Scripting, Voiceover, Rigging/Animation, Editing, Thumbnail, Review).
5. **Thumbnail & Asset Studio:** Generates AI image prompts and high-contrast color palettes specifically optimized for YouTube Kids CTR.
6. **Official YouTube API Integration:** Connects via Google OAuth 2.0 with minimal required permissions (`youtube.upload`, `youtube.readonly`, `yt-analytics.readonly`).
7. **Performance Analytics:** Tracks views, retention, and upload frequency with clear separation between verified API telemetry and model projections.
8. **Monetization Tracker:** Monitors YouTube Partner Program (YPP) thresholds (1,000 subscribers, 4,000 public watch hours, 10M Shorts views) along with COPPA non-personalized ad guidelines and production expense ROI.

---

## 🛠️ Technologies

- **Backend:** Java 17, Spring Boot 3.2.4, Spring Security, Spring Data JPA
- **Frontend:** HTML5, CSS3, Vanilla JavaScript (zero external dependencies)
- **Database:** H2 In-Memory Database (development) / MySQL (production)
- **APIs:** Official YouTube Data API v3 (`google-api-services-youtube`), Google OAuth 2.0
- **AI Engine:** Google Gemini API (`gemini-3.5-flash`)
- **Build System:** Maven

---

## 🚀 Quickstart & Installation

### 1. Prerequisites
- Java 17+ installed (`java -version`)
- Maven 3.8+ installed (`mvn -version`) or use the Maven Wrapper

### 2. Configure Environment Variables
Copy `.env.example` to `.env` or set environment variables in your terminal:

```bash
export GOOGLE_CLIENT_ID="your-client-id.apps.googleusercontent.com"
export GOOGLE_CLIENT_SECRET="your-google-client-secret"
export GEMINI_API_KEY="your-gemini-api-key"
```

### 3. Run the Spring Boot Server
```bash
mvn spring-boot:run
```

Once started, open your browser at:
👉 **`http://localhost:8080`**

To inspect the in-memory H2 database:
👉 **`http://localhost:8080/h2-console`** (JDBC URL: `jdbc:h2:mem:kidstubedb`, User: `sa`, Password: empty)

---

## 🔑 Google Cloud OAuth 2.0 Setup Guide

1. Go to the [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project: `YouTube Kids Automation Bot`.
3. Navigate to **APIs & Services > Library** and enable:
   - **YouTube Data API v3**
   - **YouTube Analytics API**
4. Configure the **OAuth Consent Screen**:
   - User Type: External
   - Add scopes:
     - `https://www.googleapis.com/auth/youtube.upload`
     - `https://www.googleapis.com/auth/youtube.readonly`
     - `https://www.googleapis.com/auth/yt-analytics.readonly`
5. Go to **Credentials > Create Credentials > OAuth client ID**:
   - Application type: Web application
   - Authorized redirect URIs: `http://localhost:8080/login/oauth2/code/google`
6. Copy the generated **Client ID** and **Client Secret** into your `.env` configuration.

---

## 🛡️ Child Safety & COPPA Guidelines

Under the Children's Online Privacy Protection Act (COPPA) and YouTube Kids Community Guidelines:
- Comments and personalized ads are permanently turned off on "Made for Kids" videos.
- Every video uploaded by the bot is flagged with `selfDeclaredMadeForKids = true`.
- The bot mandates an explicit **Owner Approval** step before any automated publishing task is dispatched.

---

## 🧪 Testing

Run standard unit and integration tests:
```bash
mvn test
```
