MERGE INTO channels KEY (id) VALUES (
    'UC-KIDSTUBE-01',
    'Sparkle Star Kids TV',
    '@sparklestartv',
    48200,
    142,
    18450200,
    'creator@kidstubestudio.org',
    TRUE,
    TRUE
);

MERGE INTO video_projects KEY (id) VALUES (
    'vid-01',
    'Learn Dinosaurs & Counting 1 to 10 with T-Rex!',
    'Join Barnaby Bunny and friendly T-Rex to count colorful dinosaur eggs! 100% Kid-Safe & Educational.',
    'dinosaurs, counting, preschool, kids songs',
    'PUBLISHED',
    'PRESCHOOL',
    4,
    'Friendly smiling T-Rex counting dinosaur eggs',
    TRUE,
    'Channel Owner',
    'dQw4w9WgXcQ',
    1791800000000,
    1791700000000
);
