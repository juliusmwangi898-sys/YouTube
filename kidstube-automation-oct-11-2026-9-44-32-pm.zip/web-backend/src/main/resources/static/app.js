document.addEventListener('DOMContentLoaded', () => {
  // Tab switching
  const navButtons = document.querySelectorAll('.nav-btn');
  const sections = document.querySelectorAll('.content-section');

  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-target');
      navButtons.forEach(b => b.classList.remove('active'));
      sections.forEach(s => s.classList.remove('active'));

      btn.classList.add('active');
      const targetSec = document.getElementById(`section-${target}`);
      if (targetSec) targetSec.classList.add('active');
    });
  });

  document.getElementById('btn-quick-generate')?.addEventListener('click', () => {
    document.querySelector('[data-target="generator"]')?.click();
  });

  // Load sample videos
  const videos = [
    { id: 'vid-01', title: 'Learn Dinosaurs & Counting 1 to 10!', age: 'Preschool (4-6)', status: 'Published', approved: true },
    { id: 'vid-02', title: 'Phonics Song: Sammy Snake Letter S', age: 'Toddlers (2-4)', status: 'Scheduled', approved: true },
    { id: 'vid-03', title: 'Why Do We Brush Our Teeth? Science Lab', age: 'Early Elementary (6-8)', status: 'Review Needed', approved: false },
    { id: 'vid-04', title: 'Safari Animal Sounds Quiz', age: 'Preschool (4-6)', status: 'In Production', approved: false }
  ];

  const tbody = document.getElementById('video-table-body');
  if (tbody) {
    tbody.innerHTML = videos.map(v => `
      <tr>
        <td><strong>${v.title}</strong></td>
        <td>${v.age}</td>
        <td>${v.status}</td>
        <td>
          <span class="${v.approved ? 'badge-approved' : 'badge-pending'}">
            ${v.approved ? '✅ Approved' : '⏳ Pending'}
          </span>
        </td>
        <td>
          <button class="btn btn-primary" style="padding: 4px 10px; font-size: 11px;" onclick="toggleApprove('${v.id}')">
            ${v.approved ? 'Revoke' : 'Approve'}
          </button>
        </td>
      </tr>
    `).join('');
  }

  // Script Generator form submit
  document.getElementById('btn-submit-generate')?.addEventListener('click', () => {
    const topic = document.getElementById('gen-topic').value;
    const age = document.getElementById('gen-age').value;
    const format = document.getElementById('gen-format').value;
    const resBox = document.getElementById('gen-result');

    resBox.style.display = 'block';
    resBox.innerHTML = `
      <div style="background: #F8FAFC; border: 1px solid #E2E8F0; padding: 16px; border-radius: 12px;">
        <h4 style="color: #FF334B;">🎬 Learn with Sparkle: ${topic}!</h4>
        <p style="font-size: 13px; margin-top: 4px;"><strong>Target:</strong> ${age} • <strong>Format:</strong> ${format}</p>
        <p style="font-size: 13px; margin-top: 6px;"><strong>Hook:</strong> Exciting 15-second opening song with friendly robot mascot greeting.</p>
        <div style="margin-top: 10px; font-size: 12px; background: white; padding: 10px; border-radius: 8px;">
          <strong>Scene 1:</strong> Colorful 3D cartoon lab introducing the topic.<br>
          <strong>Scene 2:</strong> Interactive participation question (Point your finger!).<br>
          <strong>Scene 3:</strong> Celebration fanfare and junior star badge award.
        </div>
        <p style="font-size: 11px; color: #00BA5A; margin-top: 8px;"><strong>🛡️ COPPA Check:</strong> Passed (No scary imagery, slow gentle pacing).</p>
      </div>
    `;
  });
});

window.toggleApprove = function(id) {
  alert(`Updated owner approval for video ${id}! Under YouTube Kids guidelines, owner approval is mandatory before publishing.`);
};
