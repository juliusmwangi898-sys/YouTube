CREATE TABLE IF NOT EXISTS channels (
    id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    handle VARCHAR(100),
    subscriber_count BIGINT DEFAULT 0,
    video_count INT DEFAULT 0,
    view_count BIGINT DEFAULT 0,
    connected_email VARCHAR(255),
    is_connected BOOLEAN DEFAULT TRUE,
    coppa_compliant BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS video_projects (
    id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    tags TEXT,
    status VARCHAR(50) NOT NULL,
    target_age VARCHAR(50),
    duration_minutes INT DEFAULT 4,
    thumbnail_prompt TEXT,
    is_owner_approved BOOLEAN DEFAULT FALSE,
    approved_by VARCHAR(100),
    youtube_video_id VARCHAR(64),
    scheduled_timestamp BIGINT,
    created_at BIGINT
);

CREATE TABLE IF NOT EXISTS calendar_tasks (
    id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    due_date BIGINT NOT NULL,
    is_completed BOOLEAN DEFAULT FALSE,
    reminder_enabled BOOLEAN DEFAULT TRUE
);
