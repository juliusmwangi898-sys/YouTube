package com.kidstube.automation.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class YouTubeDataApiService {

    @Value("${kidstube.youtube.channel-id:UC-KIDSTUBE-01}")
    private String channelId;

    public Map<String, Object> fetchChannelStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("channelId", channelId);
        stats.put("title", "Sparkle Star Kids TV");
        stats.put("subscriberCount", 48200L);
        stats.put("videoCount", 142);
        stats.put("viewCount", 18450200L);
        stats.put("dailyQuotaUsed", 1680);
        stats.put("dailyQuotaLimit", 10000);
        stats.put("isCoppaCompliant", true);
        return stats;
    }

    public Map<String, Object> uploadVideoMetadata(String title, String description, boolean madeForKids) {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "SUCCESS");
        response.put("youtubeVideoId", "yt-" + System.currentTimeMillis());
        response.put("title", title);
        response.put("selfDeclaredMadeForKids", madeForKids);
        return response;
    }
}
