package com.kidstube.automation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "video_projects")
public class VideoProject {

    @Id
    private String id;
    private String title;
    private String description;
    private String tags;
    private String status;
    private String targetAge;
    private int durationMinutes;
    private String thumbnailPrompt;
    private boolean isOwnerApproved;
    private String approvedBy;
    private String youtubeVideoId;
    private Long scheduledTimestamp;
    private Long createdAt;

    public VideoProject() {}

    public VideoProject(String id, String title, String description, String tags, String status, String targetAge, int durationMinutes, String thumbnailPrompt, boolean isOwnerApproved, String approvedBy, String youtubeVideoId, Long scheduledTimestamp, Long createdAt) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.tags = tags;
        this.status = status;
        this.targetAge = targetAge;
        this.durationMinutes = durationMinutes;
        this.thumbnailPrompt = thumbnailPrompt;
        this.isOwnerApproved = isOwnerApproved;
        this.approvedBy = approvedBy;
        this.youtubeVideoId = youtubeVideoId;
        this.scheduledTimestamp = scheduledTimestamp;
        this.createdAt = createdAt;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getTargetAge() { return targetAge; }
    public void setTargetAge(String targetAge) { this.targetAge = targetAge; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

    public String getThumbnailPrompt() { return thumbnailPrompt; }
    public void setThumbnailPrompt(String thumbnailPrompt) { this.thumbnailPrompt = thumbnailPrompt; }

    public boolean isOwnerApproved() { return isOwnerApproved; }
    public void setOwnerApproved(boolean ownerApproved) { isOwnerApproved = ownerApproved; }

    public String getApprovedBy() { return approvedBy; }
    public void setApprovedBy(String approvedBy) { this.approvedBy = approvedBy; }

    public String getYoutubeVideoId() { return youtubeVideoId; }
    public void setYoutubeVideoId(String youtubeVideoId) { this.youtubeVideoId = youtubeVideoId; }

    public Long getScheduledTimestamp() { return scheduledTimestamp; }
    public void setScheduledTimestamp(Long scheduledTimestamp) { this.scheduledTimestamp = scheduledTimestamp; }

    public Long getCreatedAt() { return createdAt; }
    public void setCreatedAt(Long createdAt) { this.createdAt = createdAt; }
}
