package com.kidstube.automation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KidsTubeApplication {

    public static void main(String[] args) {
        SpringApplication.run(KidsTubeApplication.class, args);
    }
}
