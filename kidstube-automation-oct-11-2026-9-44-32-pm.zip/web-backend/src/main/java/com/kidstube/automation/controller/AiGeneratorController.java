package com.kidstube.automation.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/generator")
public class AiGeneratorController {

    @PostMapping("/generate")
    public ResponseEntity<Map<String, Object>> generateContent(@RequestBody Map<String, String> request) {
        String topic = request.getOrDefault("topic", "Dinosaur Counting");
        String ageGroup = request.getOrDefault("ageGroup", "PRESCHOOL");
        String format = request.getOrDefault("format", "LESSON");

        Map<String, Object> script = Map.of(
            "id", UUID.randomUUID().toString(),
            "title", "Learn with Sparkle: " + topic + "!",
            "targetAge", ageGroup,
            "format", format,
            "targetDurationMinutes", 4,
            "educationalObjective", "Montessori aligned cognitive exploration and positive habit formation for " + topic,
            "scenes", List.of(
                Map.of("sceneNumber", 1, "title", "Exciting Hook", "visual", "Vibrant 3D cartoon lab", "dialogue", "Hello little thinkers! Today we discover " + topic + "!", "durationSec", 30),
                Map.of("sceneNumber", 2, "title", "Fun Demonstration", "visual", "Character points to colorful floating elements", "dialogue", "Look closely at step one!", "durationSec", 50),
                Map.of("sceneNumber", 3, "title", "Child Participation Quiz", "visual", "Two big star buttons countdown", "dialogue", "Which one is right? Point your finger!", "durationSec", 40),
                Map.of("sceneNumber", 4, "title", "Celebration & Moral", "visual", "Confetti and golden junior badge", "dialogue", "Great job! You earned your explorer star!", "durationSec", 30)
            ),
            "thumbnailPrompt", "A vibrant 3D cartoon thumbnail for YouTube Kids: adorable smiling characters learning about " + topic + ", bright yellow background, Pixar style, 16:9",
            "coppaCompliance", "Strictly Made for Kids. Gentle pacing, no scary elements, positive reinforcement."
        );

        return ResponseEntity.ok(script);
    }
}
