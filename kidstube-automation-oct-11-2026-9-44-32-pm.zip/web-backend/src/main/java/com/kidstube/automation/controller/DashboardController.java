package com.kidstube.automation.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @GetMapping("/summary")
    public ResponseEntity<Map<String, Object>> getDashboardSummary() {
        Map<String, Object> data = new HashMap<>();
        data.put("channelName", "Sparkle Star Kids TV");
        data.put("handle", "@sparklestartv");
        data.put("subscribers", 48200);
        data.put("totalViews", 18450200);
        data.put("totalWatchHours", 520400);
        data.put("publishedVideos", 142);
        data.put("coppaCompliant", true);
        data.put("connectedEmail", "creator@kidstubestudio.org");
        data.put("recentActivities", List.of(
            Map.of("title", "Video Published", "detail", "'Dinosaur Counting 1-10' is live on YouTube Kids", "time", "1 day ago"),
            Map.of("title", "Script Generated", "detail", "New script ready for 'Why Brush Teeth?'", "time", "2 days ago"),
            Map.of("title", "Milestone", "detail", "Passed 48,000 subscribers!", "time", "4 days ago")
        ));
        return ResponseEntity.ok(data);
    }
}
