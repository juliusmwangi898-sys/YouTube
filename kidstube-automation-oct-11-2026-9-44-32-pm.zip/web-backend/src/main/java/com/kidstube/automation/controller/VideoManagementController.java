package com.kidstube.automation.controller;

import com.kidstube.automation.model.VideoProject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/videos")
public class VideoManagementController {

    private final Map<String, VideoProject> videoDatabase = new HashMap<>();

    public VideoManagementController() {
        VideoProject v1 = new VideoProject(
            "vid-01",
            "Learn Dinosaurs & Counting 1 to 10!",
            "Count colorful dino eggs with Barnaby Bunny",
            "dinosaurs, counting, kids songs",
            "PUBLISHED",
            "PRESCHOOL",
            4,
            "Smiling T-Rex with eggs",
            true,
            "Channel Owner",
            "dQw4w9WgXcQ",
            System.currentTimeMillis(),
            System.currentTimeMillis()
        );
        videoDatabase.put(v1.getId(), v1);
    }

    @GetMapping
    public ResponseEntity<List<VideoProject>> getAllVideos() {
        return ResponseEntity.ok(new ArrayList<>(videoDatabase.values()));
    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<?> approveVideo(@PathVariable String id, @RequestParam(defaultValue = "Channel Owner") String approver) {
        VideoProject video = videoDatabase.get(id);
        if (video == null) {
            return ResponseEntity.notFound().build();
        }
        video.setOwnerApproved(true);
        video.setApprovedBy(approver);
        video.setStatus("APPROVED");
        return ResponseEntity.ok(Map.of("message", "Video approved by owner", "video", video));
    }

    @PostMapping("/{id}/publish")
    public ResponseEntity<?> publishVideo(@PathVariable String id) {
        VideoProject video = videoDatabase.get(id);
        if (video == null) {
            return ResponseEntity.notFound().build();
        }
        // Strict compliance check
        if (!video.isOwnerApproved()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error", "OWNER_APPROVAL_REQUIRED",
                "message", "Under COPPA & YouTube Kids policy, owner must explicitly approve video before publishing."
            ));
        }

        video.setStatus("PUBLISHED");
        video.setYoutubeVideoId("yt-" + UUID.randomUUID().toString().substring(0, 8));
        return ResponseEntity.ok(Map.of("message", "Video published to YouTube Kids", "video", video));
    }
}
