package com.example

import com.example.data.service.GeminiScriptEngine
import com.example.model.AgeGroup
import com.example.model.ContentFormat
import com.example.model.MonetizationStatus
import com.example.model.VideoProject
import com.example.model.VideoStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun scriptEngine_generatesMultiSceneKidsStoryboard() {
        val engine = GeminiScriptEngine()
        val script = engine.generateSpecializedKidsScript(
            topic = "Phonics Letters ABC",
            ageGroup = AgeGroup.PRESCHOOL,
            format = ContentFormat.SONG,
            language = "English"
        )

        assertNotNull(script.title)
        assertTrue(script.scenes.isNotEmpty())
        assertEquals(4, script.scenes.size)
        assertTrue(script.safetyComplianceNotes.contains("COPPA"))
        assertTrue(script.thumbnailPrompt.contains("YouTube Kids"))
    }

    @Test
    fun videoPipeline_blocksPublishWithoutOwnerApproval() {
        val unapprovedVideo = VideoProject(
            id = "test-vid-1",
            title = "Test Dino Video",
            description = "Desc",
            tags = listOf("kids"),
            status = VideoStatus.REVIEW,
            ageGroup = AgeGroup.TODDLERS,
            durationMinutes = 3,
            thumbnailPrompt = "Prompt",
            isOwnerApproved = false
        )

        // Enforce YouTube Kids policy mandate: Owner must explicitly approve
        assertFalse(unapprovedVideo.isOwnerApproved)

        val approvedVideo = unapprovedVideo.copy(
            isOwnerApproved = true,
            status = VideoStatus.APPROVED,
            approvedBy = "Owner (Signed)"
        )

        assertTrue(approvedVideo.isOwnerApproved)
        assertEquals(VideoStatus.APPROVED, approvedVideo.status)
    }

    @Test
    fun monetizationStatus_calculatesNetProfitAndProgress() {
        val status = MonetizationStatus(
            subscriberCount = 5000L,
            subscriberGoal = 1000L,
            watchHours = 6000L,
            watchHoursGoal = 4000L,
            estimatedMonthlyRevenue = 4000.0,
            productionExpenses = 1000.0
        )

        assertEquals(3000.0, status.netMonthlyProfit, 0.01)
        assertEquals(1.0f, status.subProgressRatio, 0.01f)
        assertEquals(1.0f, status.watchHoursProgressRatio, 0.01f)
        assertTrue(status.isYppEligible)
    }
}
