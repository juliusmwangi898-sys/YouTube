package com.example.model

enum class VideoStatus(val label: String) {
    DRAFT("Draft"),
    SCRIPTED("Script Ready"),
    IN_PRODUCTION("In Production"),
    REVIEW("Needs Review"),
    APPROVED("Owner Approved"),
    SCHEDULED("Scheduled"),
    PUBLISHED("Published")
}

enum class AgeGroup(val label: String, val range: String) {
    TODDLERS("Toddlers", "2-4 Years"),
    PRESCHOOL("Preschool", "4-6 Years"),
    EARLY_ELEMENTARY("Early Elementary", "6-8 Years"),
    TWEENS("Tweens", "9-12 Years")
}

enum class ContentFormat(val label: String) {
    STORY("Animated Story"),
    SONG("Nursery Rhyme & Song"),
    LESSON("Educational Lesson"),
    QUIZ("Interactive Quiz")
}

data class ChannelInfo(
    val channelId: String = "UC-KIDSTUBE-DEMO-01",
    val title: String = "Sparkle Star Kids TV",
    val handle: String = "@sparklestartv",
    val subscriberCount: Long = 48200L,
    val videoCount: Int = 142,
    val viewCount: Long = 18450200L,
    val isConnected: Boolean = true,
    val connectedAccountEmail: String = "creator@kidstubestudio.org",
    val coppaCompliant: Boolean = true,
    val defaultLanguage: String = "English (US)"
)

data class StoryboardScene(
    val sceneNumber: Int,
    val title: String,
    val visualDescription: String,
    val characterAction: String,
    val voiceoverText: String,
    val sfxAndMusic: String,
    val durationSec: Int
)

data class ScriptIdea(
    val id: String,
    val title: String,
    val topic: String,
    val ageGroup: AgeGroup,
    val contentFormat: ContentFormat,
    val language: String,
    val targetLengthMinutes: Int,
    val hook: String,
    val educationalObjective: String,
    val scenes: List<StoryboardScene>,
    val seoTitleSuggestions: List<String>,
    val description: String,
    val tags: List<String>,
    val thumbnailPrompt: String,
    val safetyComplianceNotes: String,
    val createdAt: Long = System.currentTimeMillis()
)

data class VideoProject(
    val id: String,
    val title: String,
    val description: String,
    val tags: List<String>,
    val status: VideoStatus,
    val ageGroup: AgeGroup,
    val durationMinutes: Int,
    val thumbnailPrompt: String,
    val thumbnailUri: String? = null,
    val isOwnerApproved: Boolean = false,
    val approvedBy: String? = null,
    val scheduledPublishTimestamp: Long? = null,
    val youtubeVideoId: String? = null,
    val uploadProgressPercent: Int = 0,
    val uploadStatusText: String = "Ready",
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class CalendarTask(
    val id: String,
    val videoProjectId: String? = null,
    val title: String,
    val category: String, // "Script", "Voiceover", "Animation", "Editing", "Thumbnail", "Upload"
    val dueDateTimestamp: Long,
    val isCompleted: Boolean = false,
    val reminderEnabled: Boolean = true
)

data class AssetItem(
    val id: String,
    val title: String,
    val type: String, // "Thumbnail Concept", "Audio Track", "Character Sheet", "Voiceover"
    val colorPaletteHex: List<String>,
    val aiPrompt: String,
    val fileSizeText: String,
    val projectName: String,
    val previewEmoji: String = "🎨"
)

data class VideoPerformanceStat(
    val videoId: String,
    val title: String,
    val views: Long,
    val likes: Long,
    val watchTimeHours: Double,
    val publishedDaysAgo: Int,
    val thumbnailColorHex: Long = 0xFFFF334B
)

data class AnalyticsOverview(
    val totalViews: Long = 18450200L,
    val viewsChangePercent: Double = 14.8,
    val totalWatchHours: Long = 520400L,
    val subscribersTotal: Long = 48200L,
    val subscribersGained: Long = 2450L,
    val avgRetentionRate: Double = 68.4,
    val clickThroughRate: Double = 11.2,
    val uploadFrequencyPerWeek: Double = 3.5,
    val isRealApiConnected: Boolean = true,
    val topVideos: List<VideoPerformanceStat> = emptyList()
)

data class MonetizationStatus(
    val subscriberCount: Long = 48200L,
    val subscriberGoal: Long = 1000L,
    val watchHours: Long = 520400L,
    val watchHoursGoal: Long = 4000L,
    val shortsViews: Long = 12500000L,
    val shortsViewsGoal: Long = 10000000L,
    val coppaCompliant: Boolean = true,
    val isYppEligible: Boolean = true,
    val estimatedMonthlyRevenue: Double = 3840.50,
    val productionExpenses: Double = 950.00
) {
    val netMonthlyProfit: Double get() = estimatedMonthlyRevenue - productionExpenses
    val subProgressRatio: Float get() = (subscriberCount.toFloat() / subscriberGoal).coerceAtMost(1f)
    val watchHoursProgressRatio: Float get() = (watchHours.toFloat() / watchHoursGoal).coerceAtMost(1f)
    val shortsProgressRatio: Float get() = (shortsViews.toFloat() / shortsViewsGoal).coerceAtMost(1f)
}

data class YouTubeApiSettings(
    val clientId: String = "93821034-kidstube-app.apps.googleusercontent.com",
    val apiKey: String = "",
    val connectedChannelName: String = "Sparkle Star Kids TV",
    val isConnected: Boolean = true,
    val quotaUsedToday: Int = 1680,
    val quotaLimitDaily: Int = 10000,
    val scopesGranted: List<String> = listOf(
        "https://www.googleapis.com/auth/youtube.upload",
        "https://www.googleapis.com/auth/youtube.readonly",
        "https://www.googleapis.com/auth/yt-analytics.readonly"
    )
)
