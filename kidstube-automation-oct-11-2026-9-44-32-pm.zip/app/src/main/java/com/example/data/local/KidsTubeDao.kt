package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface KidsTubeDao {

    // Videos
    @Query("SELECT * FROM video_projects ORDER BY createdAt DESC")
    fun getAllVideos(): Flow<List<VideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: VideoEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideos(videos: List<VideoEntity>)

    @Update
    suspend fun updateVideo(video: VideoEntity)

    @Query("DELETE FROM video_projects WHERE id = :id")
    suspend fun deleteVideo(id: String)

    // Scripts
    @Query("SELECT * FROM script_ideas ORDER BY createdAt DESC")
    fun getAllScripts(): Flow<List<ScriptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScript(script: ScriptEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScripts(scripts: List<ScriptEntity>)

    @Query("DELETE FROM script_ideas WHERE id = :id")
    suspend fun deleteScript(id: String)

    // Calendar tasks
    @Query("SELECT * FROM calendar_tasks ORDER BY dueDateTimestamp ASC")
    fun getAllTasks(): Flow<List<CalendarTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: CalendarTaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<CalendarTaskEntity>)

    @Update
    suspend fun updateTask(task: CalendarTaskEntity)

    @Query("DELETE FROM calendar_tasks WHERE id = :id")
    suspend fun deleteTask(id: String)

    // Assets
    @Query("SELECT * FROM asset_items")
    fun getAllAssets(): Flow<List<AssetItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAsset(asset: AssetItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssets(assets: List<AssetItemEntity>)

    @Query("DELETE FROM asset_items WHERE id = :id")
    suspend fun deleteAsset(id: String)

    // Channel config
    @Query("SELECT * FROM channel_config WHERE id = 'active_channel' LIMIT 1")
    fun getChannelConfig(): Flow<ChannelConfigEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveChannelConfig(config: ChannelConfigEntity)
}
