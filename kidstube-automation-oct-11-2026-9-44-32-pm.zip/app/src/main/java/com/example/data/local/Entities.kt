package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.AgeGroup
import com.example.model.ContentFormat
import com.example.model.StoryboardScene
import com.example.model.VideoStatus

@Entity(tableName = "video_projects")
data class VideoEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val tags: List<String>,
    val status: VideoStatus,
    val ageGroup: AgeGroup,
    val durationMinutes: Int,
    val thumbnailPrompt: String,
    val thumbnailUri: String?,
    val isOwnerApproved: Boolean,
    val approvedBy: String?,
    val scheduledPublishTimestamp: Long?,
    val youtubeVideoId: String?,
    val uploadProgressPercent: Int,
    val uploadStatusText: String,
    val errorMessage: String?,
    val createdAt: Long
)

@Entity(tableName = "script_ideas")
data class ScriptEntity(
    @PrimaryKey val id: String,
    val title: String,
    val topic: String,
    val ageGroup: AgeGroup,
    val contentFormat: ContentFormat,
    val language: String,
    val targetLengthMinutes: Int,
    val hook: String,
    val educationalObjective: String,
    val scenes: List<StoryboardScene>,
    val seoTitleSuggestions: List<String>,
    val description: String,
    val tags: List<String>,
    val thumbnailPrompt: String,
    val safetyComplianceNotes: String,
    val createdAt: Long
)

@Entity(tableName = "calendar_tasks")
data class CalendarTaskEntity(
    @PrimaryKey val id: String,
    val videoProjectId: String?,
    val title: String,
    val category: String,
    val dueDateTimestamp: Long,
    val isCompleted: Boolean,
    val reminderEnabled: Boolean
)

@Entity(tableName = "asset_items")
data class AssetItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val type: String,
    val colorPaletteHex: List<String>,
    val aiPrompt: String,
    val fileSizeText: String,
    val projectName: String,
    val previewEmoji: String
)

@Entity(tableName = "channel_config")
data class ChannelConfigEntity(
    @PrimaryKey val id: String = "active_channel",
    val title: String,
    val handle: String,
    val subscriberCount: Long,
    val videoCount: Int,
    val viewCount: Long,
    val isConnected: Boolean,
    val connectedEmail: String,
    val coppaCompliant: Boolean,
    val defaultLanguage: String,
    val apiKey: String,
    val clientId: String,
    val quotaUsedToday: Int
)
