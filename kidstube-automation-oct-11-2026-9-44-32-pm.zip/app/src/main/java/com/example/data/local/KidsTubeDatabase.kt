package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        VideoEntity::class,
        ScriptEntity::class,
        CalendarTaskEntity::class,
        AssetItemEntity::class,
        ChannelConfigEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(KidsTubeConverters::class)
abstract class KidsTubeDatabase : RoomDatabase() {

    abstract fun kidsTubeDao(): KidsTubeDao

    companion object {
        @Volatile
        private var INSTANCE: KidsTubeDatabase? = null

        fun getDatabase(context: Context): KidsTubeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KidsTubeDatabase::class.java,
                    "kidstube_automation_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
