package com.example.data.local

import androidx.room.TypeConverter
import com.example.model.AgeGroup
import com.example.model.ContentFormat
import com.example.model.StoryboardScene
import com.example.model.VideoStatus
import org.json.JSONArray
import org.json.JSONObject

class KidsTubeConverters {

    @TypeConverter
    fun fromStringList(list: List<String>?): String {
        if (list == null) return "[]"
        val array = JSONArray()
        list.forEach { array.put(it) }
        return array.toString()
    }

    @TypeConverter
    fun toStringList(data: String?): List<String> {
        if (data.isNullOrEmpty()) return emptyList()
        val list = mutableListOf<String>()
        val array = JSONArray(data)
        for (i in 0 until array.length()) {
            list.add(array.getString(i))
        }
        return list
    }

    @TypeConverter
    fun fromScenesList(scenes: List<StoryboardScene>?): String {
        if (scenes == null) return "[]"
        val array = JSONArray()
        scenes.forEach { scene ->
            val obj = JSONObject().apply {
                put("sceneNumber", scene.sceneNumber)
                put("title", scene.title)
                put("visualDescription", scene.visualDescription)
                put("characterAction", scene.characterAction)
                put("voiceoverText", scene.voiceoverText)
                put("sfxAndMusic", scene.sfxAndMusic)
                put("durationSec", scene.durationSec)
            }
            array.put(obj)
        }
        return array.toString()
    }

    @TypeConverter
    fun toScenesList(data: String?): List<StoryboardScene> {
        if (data.isNullOrEmpty()) return emptyList()
        val list = mutableListOf<StoryboardScene>()
        val array = JSONArray(data)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                StoryboardScene(
                    sceneNumber = obj.optInt("sceneNumber", i + 1),
                    title = obj.optString("title", ""),
                    visualDescription = obj.optString("visualDescription", ""),
                    characterAction = obj.optString("characterAction", ""),
                    voiceoverText = obj.optString("voiceoverText", ""),
                    sfxAndMusic = obj.optString("sfxAndMusic", ""),
                    durationSec = obj.optInt("durationSec", 30)
                )
            )
        }
        return list
    }

    @TypeConverter
    fun fromVideoStatus(status: VideoStatus): String = status.name

    @TypeConverter
    fun toVideoStatus(value: String): VideoStatus = try {
        VideoStatus.valueOf(value)
    } catch (_: Exception) {
        VideoStatus.DRAFT
    }

    @TypeConverter
    fun fromAgeGroup(age: AgeGroup): String = age.name

    @TypeConverter
    fun toAgeGroup(value: String): AgeGroup = try {
        AgeGroup.valueOf(value)
    } catch (_: Exception) {
        AgeGroup.PRESCHOOL
    }

    @TypeConverter
    fun fromContentFormat(format: ContentFormat): String = format.name

    @TypeConverter
    fun toContentFormat(value: String): ContentFormat = try {
        ContentFormat.valueOf(value)
    } catch (_: Exception) {
        ContentFormat.STORY
    }
}
