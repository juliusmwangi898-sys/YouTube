package com.example.data.service

import com.example.BuildConfig
import com.example.model.AgeGroup
import com.example.model.ContentFormat
import com.example.model.ScriptIdea
import com.example.model.StoryboardScene
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

class GeminiScriptEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateKidsContent(
        topic: String,
        ageGroup: AgeGroup,
        format: ContentFormat,
        language: String
    ): ScriptIdea = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (!apiKey.isNullOrEmpty() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val result = callGeminiApi(apiKey, topic, ageGroup, format, language)
                if (result != null) return@withContext result
            } catch (e: Exception) {
                // Graceful fallback to built-in generator if network fails
            }
        }
        return@withContext generateSpecializedKidsScript(topic, ageGroup, format, language)
    }

    private fun callGeminiApi(
        apiKey: String,
        topic: String,
        ageGroup: AgeGroup,
        format: ContentFormat,
        language: String
    ): ScriptIdea? {
        val prompt = """
            You are an expert children's educational television writer and YouTube Kids channel director.
            Generate a complete video script and storyboard for children.
            Topic: "$topic"
            Age Group: ${ageGroup.label} (${ageGroup.range})
            Format: ${format.label}
            Language: $language

            Return a valid JSON object matching this schema:
            {
              "title": "Fun Kid-Friendly Title",
              "hook": "15-second exciting opening hook for kids",
              "educationalObjective": "What children will learn",
              "targetLengthMinutes": 4,
              "seoTitles": ["Title 1", "Title 2", "Title 3"],
              "description": "Engaging description with timestamps and safety tips",
              "tags": ["tag1", "tag2", "tag3"],
              "thumbnailPrompt": "A vibrant 3D cartoon thumbnail with bold text and smiling characters",
              "safetyComplianceNotes": "COPPA compliance, gentle pacing, positive messaging",
              "scenes": [
                {
                  "sceneNumber": 1,
                  "title": "Scene Title",
                  "visualDescription": "Visual scenery description",
                  "characterAction": "Character movements",
                  "voiceoverText": "Spoken dialogue or song lyrics",
                  "sfxAndMusic": "Sound effect and music style",
                  "durationSec": 30
                }
              ]
            }
        """.trimIndent()

        val jsonRequest = JSONObject().apply {
            val contents = JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            }
            put("contents", contents)
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            })
        }

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
            .post(jsonRequest.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) return null

        val responseBody = response.body?.string() ?: return null
        val root = JSONObject(responseBody)
        val candidates = root.optJSONArray("candidates") ?: return null
        val firstCandidate = candidates.optJSONObject(0) ?: return null
        val text = firstCandidate.optJSONObject("content")
            ?.optJSONArray("parts")
            ?.optJSONObject(0)
            ?.optString("text") ?: return null

        val parsed = JSONObject(text)
        val scenesArray = parsed.optJSONArray("scenes") ?: JSONArray()
        val scenes = mutableListOf<StoryboardScene>()
        for (i in 0 until scenesArray.length()) {
            val sc = scenesArray.getJSONObject(i)
            scenes.add(
                StoryboardScene(
                    sceneNumber = sc.optInt("sceneNumber", i + 1),
                    title = sc.optString("title", "Scene ${i + 1}"),
                    visualDescription = sc.optString("visualDescription", ""),
                    characterAction = sc.optString("characterAction", ""),
                    voiceoverText = sc.optString("voiceoverText", ""),
                    sfxAndMusic = sc.optString("sfxAndMusic", "Playful background music"),
                    durationSec = sc.optInt("durationSec", 30)
                )
            )
        }

        val seoTitles = mutableListOf<String>()
        val seoArray = parsed.optJSONArray("seoTitles")
        if (seoArray != null) {
            for (i in 0 until seoArray.length()) seoTitles.add(seoArray.getString(i))
        }

        val tags = mutableListOf<String>()
        val tagsArray = parsed.optJSONArray("tags")
        if (tagsArray != null) {
            for (i in 0 until tagsArray.length()) tags.add(tagsArray.getString(i))
        }

        return ScriptIdea(
            id = UUID.randomUUID().toString(),
            title = parsed.optString("title", topic),
            topic = topic,
            ageGroup = ageGroup,
            contentFormat = format,
            language = language,
            targetLengthMinutes = parsed.optInt("targetLengthMinutes", 4),
            hook = parsed.optString("hook", "Welcome little explorers!"),
            educationalObjective = parsed.optString("educationalObjective", "Early childhood concept exploration"),
            scenes = scenes,
            seoTitleSuggestions = seoTitles,
            description = parsed.optString("description", "Join us for fun learning on Sparkle Star TV!"),
            tags = tags,
            thumbnailPrompt = parsed.optString("thumbnailPrompt", "Vibrant friendly cartoon characters smiling"),
            safetyComplianceNotes = parsed.optString("safetyComplianceNotes", "COPPA verified, safe for kids"),
            createdAt = System.currentTimeMillis()
        )
    }

    fun generateSpecializedKidsScript(
        topic: String,
        ageGroup: AgeGroup,
        format: ContentFormat,
        language: String
    ): ScriptIdea {
        val cleanTopic = if (topic.isBlank()) "Dinosaur Adventure & Counting" else topic.trim()
        val title = "Learn with Sparkle: $cleanTopic!"

        val scenes = when (format) {
            ContentFormat.SONG -> listOf(
                StoryboardScene(
                    sceneNumber = 1,
                    title = "Opening Hook & Melody",
                    visualDescription = "Bright pastel rainbow landscape with Sparkle the friendly robot tapping feet to a cheerful drumbeat.",
                    characterAction = "Sparkle waves both hands with sparkling golden stars appearing around.",
                    voiceoverText = "(Upbeat Melody) Come along and sing with me, let's explore $cleanTopic from A to Z! Clap your hands, one two three!",
                    sfxAndMusic = "Bright acoustic guitar with chime bell glissando",
                    durationSec = 25
                ),
                StoryboardScene(
                    sceneNumber = 2,
                    title = "Verse 1 - Discovering the Concept",
                    visualDescription = "Large 3D colorful letters and floating friendly character balloons corresponding to $cleanTopic.",
                    characterAction = "Characters bounce rhythmically and point to each item as it glows yellow.",
                    voiceoverText = "Look right here, what can you see? Can you count along with me? One, two, three, happy as can be!",
                    sfxAndMusic = "Upbeat xylophone and whistle accents",
                    durationSec = 45
                ),
                StoryboardScene(
                    sceneNumber = 3,
                    title = "Interactive Chorus - Child Participation",
                    visualDescription = "On-screen speech bubble asking 'Can you jump like a friendly kangaroo?' followed by slow countdown.",
                    characterAction = "Sparkle jumps high into the clouds and catches stars.",
                    voiceoverText = "Now it's your turn! Stand up tall, wiggle your toes and have a ball! Sing: $cleanTopic is so cool!",
                    sfxAndMusic = "Joyful brass fanfare and soft clapping track",
                    durationSec = 40
                ),
                StoryboardScene(
                    sceneNumber = 4,
                    title = "Gentle Outro & Positive Reinforcement",
                    visualDescription = "Sun slowly setting over peaceful rainbow hills with cozy stars waving goodnight.",
                    characterAction = "Sparkle gives a warm hug to the camera.",
                    voiceoverText = "You did such a wonderful job today! High five! Don't forget to smile and be kind!",
                    sfxAndMusic = "Calm lullaby glockenspiel resolution",
                    durationSec = 30
                )
            )
            ContentFormat.STORY -> listOf(
                StoryboardScene(
                    sceneNumber = 1,
                    title = "The Mysterious Sound",
                    visualDescription = "Sunny meadow with oversized giant mushrooms, smiling flowers, and a cozy treehouse.",
                    characterAction = "Barnaby the Bunny tilts his long ears and looks curious at a golden glowing chest.",
                    voiceoverText = "Once upon a sunny morning, Barnaby the Bunny heard a magical sound coming from the magical woods...",
                    sfxAndMusic = "Soft harp arpeggios and birds chirping gently",
                    durationSec = 35
                ),
                StoryboardScene(
                    sceneNumber = 2,
                    title = "The Friendly Teamwork Challenge",
                    visualDescription = "A wide friendly river with stepping stones shaped like numbers and shapes.",
                    characterAction = "Barnaby meets Mia the Monkey. Mia offers a bamboo stick to help Barnaby cross safely.",
                    voiceoverText = "'Don't worry Barnaby!' called Mia. 'When friends work together, there is no puzzle we can't solve!'",
                    sfxAndMusic = "Playful pizzicato strings and bubbly water splashes",
                    durationSec = 50
                ),
                StoryboardScene(
                    sceneNumber = 3,
                    title = "Solving the Riddle of $cleanTopic",
                    visualDescription = "A shining crystal cave with friendly glowworms forming the key concepts of $cleanTopic.",
                    characterAction = "Together they match the puzzle pieces into place. The whole cave lights up with happy colors.",
                    voiceoverText = "'Look at that!' cheered Mia. By sharing and helping each other, we learned all about $cleanTopic!",
                    sfxAndMusic = "Sparkling chime crescendo and warm applause",
                    durationSec = 45
                ),
                StoryboardScene(
                    sceneNumber = 4,
                    title = "The Celebration Feast & Moral",
                    visualDescription = "Picnic table covered with delicious berries, honey treats, and fruit smoothies.",
                    characterAction = "All the forest animals dance in a circle holding hands.",
                    voiceoverText = "And so Barnaby learned that the greatest treasure of all was friendship, patience, and asking questions!",
                    sfxAndMusic = "Festive cheerful accordion and warm acoustic strings",
                    durationSec = 35
                )
            )
            ContentFormat.LESSON -> listOf(
                StoryboardScene(
                    sceneNumber = 1,
                    title = "Big Question Hook",
                    visualDescription = "Vibrant animated science laboratory with bubbly test tubes that sparkle in pink and cyan.",
                    characterAction = "Professor Paws adjusts big round glasses and wiggles whiskers with excitement.",
                    voiceoverText = "Hello curious thinkers! Have you ever wondered why $cleanTopic happens? Today we become detectives!",
                    sfxAndMusic = "Bubbly laboratory sound effects and playful marimba",
                    durationSec = 30
                ),
                StoryboardScene(
                    sceneNumber = 2,
                    title = "Step-by-Step Visual Demonstration",
                    visualDescription = "Split screen comparing 3D models with large clear labels in rounded child-friendly typography.",
                    characterAction = "Professor Paws points with a starry pointer stick. Items magnify smoothly.",
                    voiceoverText = "Rule number one! Look closely at how this works. Step by step, it's easier than you think!",
                    sfxAndMusic = "Light rhythmic clock ticking and gentle xylophone",
                    durationSec = 55
                ),
                StoryboardScene(
                    sceneNumber = 3,
                    title = "Interactive Quick Quiz",
                    visualDescription = "Two big friendly buttons appear: Option A (Star) and Option B (Heart). 5-second countdown timer.",
                    characterAction = "Professor Paws cups ears toward the viewer: 'Which one do you think is right? Point with your finger!'",
                    voiceoverText = "Which one matches our lesson? Is it the Star or the Heart? You chose... THE STAR! Ding ding ding! Correct!",
                    sfxAndMusic = "Cheerful quiz chime ding! and confetti pop",
                    durationSec = 40
                ),
                StoryboardScene(
                    sceneNumber = 4,
                    title = "Summary & Badge Award",
                    visualDescription = "Golden 'Junior Science Explorer' badge stamp awarded to the center of the screen.",
                    characterAction = "Professor Paws salutes and gives double thumbs up.",
                    voiceoverText = "Congratulations! You have earned today's Explorer Badge in $cleanTopic! Keep asking questions and stay curious!",
                    sfxAndMusic = "Triumphant gentle trumpet fanfare",
                    durationSec = 30
                )
            )
            ContentFormat.QUIZ -> listOf(
                StoryboardScene(
                    sceneNumber = 1,
                    title = "Game Show Opening",
                    visualDescription = "Colorful TV studio with balloon arches, spinning prize wheel, and twinkling stage lights.",
                    characterAction = "Pip the Penguin bounces out wearing a golden bow tie and holding a microphone.",
                    voiceoverText = "Welcome to the Super Fun Kids Game Show! Today's challenge is all about $cleanTopic!",
                    sfxAndMusic = "Fun game show intro music and cheerful audience laughter",
                    durationSec = 25
                ),
                StoryboardScene(
                    sceneNumber = 2,
                    title = "Round 1: Guess the Sound & Picture",
                    visualDescription = "Silhouette mystery box vibrating with a funny muffled sound.",
                    characterAction = "Pip winks and counts down on three penguin flippers: 3, 2, 1...",
                    voiceoverText = "Listen carefully! What makes that sound? Shout out your answer as loud as you can!",
                    sfxAndMusic = "Funny mystery boing sound effect followed by reveal fanfare",
                    durationSec = 45
                ),
                StoryboardScene(
                    sceneNumber = 3,
                    title = "Round 2: The Speed Challenge",
                    visualDescription = "Four colorful boxes moving across the screen. Target is to spot the correct matching piece.",
                    characterAction = "Pip runs back and forth excitedly pointing.",
                    voiceoverText = "You are so fast! Can you find the matching color before time runs out? Wow, look at that super speed!",
                    sfxAndMusic = "Fast bouncy woodblock beat and sparkling bells",
                    durationSec = 40
                ),
                StoryboardScene(
                    sceneNumber = 4,
                    title = "Champion Trophy Ceremony",
                    visualDescription = "Giant sparkling rainbow trophy with golden ribbons raining down.",
                    characterAction = "Pip does the penguin victory waddle dance.",
                    voiceoverText = "You are today's Super Champion! You scored 100 out of 100 stars! Share your high score with mom and dad!",
                    sfxAndMusic = "Celebratory fireworks pop sound and happy cheer",
                    durationSec = 30
                )
            )
        }

        val seoTitles = listOf(
            "$cleanTopic for Kids! 🌟 Fun Learning with Sparkle TV (${ageGroup.range})",
            "Learn $cleanTopic The Easy Way! 🎈 Educational Cartoon for Children",
            "Sing & Learn: $cleanTopic | Best Kids Songs & Educational Stories 2026"
        )

        val tags = listOf(
            "kids learning",
            "youtube kids",
            "educational videos for toddlers",
            "children story",
            cleanTopic.lowercase(),
            "preschool learning",
            "sparkle star tv",
            "safe kids content",
            "learning songs",
            "nursery rhymes",
            "family friendly"
        )

        val thumbnailPrompt = "A joyful vibrant 3D Pixar-style cartoon of a friendly robot creator and cute forest animals learning about $cleanTopic, bold yellow and cyan typography 'LEARN $cleanTopic!', high contrast 16:9 thumbnail, glowing magical sparkles, bright saturated colors, YouTube Kids style"

        return ScriptIdea(
            id = UUID.randomUUID().toString(),
            title = title,
            topic = cleanTopic,
            ageGroup = ageGroup,
            contentFormat = format,
            language = language,
            targetLengthMinutes = (scenes.sumOf { it.durationSec } / 60).coerceAtLeast(3),
            hook = "Exciting 15-second opening hook with character greeting, catchy rhyme, and clear learning goal for ${ageGroup.range}.",
            educationalObjective = "Develops cognitive recognition, listening comprehension, positive emotional intelligence, and concept retention for $cleanTopic.",
            scenes = scenes,
            seoTitleSuggestions = seoTitles,
            description = """
                🌟 Welcome to Sparkle Star Kids TV! In this fun and safe episode, children will learn all about $cleanTopic through catchy songs, vibrant 3D animations, and interactive questions!
                
                ⏱️ TIMESTAMPS:
                0:00 - Fun Intro & Hello Song
                0:30 - Discovering $cleanTopic
                1:45 - Interactive Play Along
                2:50 - Champion Quiz & Celebration
                3:40 - Hugs & Goodbye!
                
                🛡️ CHILD SAFETY & COPPA:
                This video is strictly 'Made for Kids' and follows YouTube Kids Community Guidelines. No aggressive flashing, no scary sounds, 100% wholesome educational family content.
            """.trimIndent(),
            tags = tags,
            thumbnailPrompt = thumbnailPrompt,
            safetyComplianceNotes = "COPPA compliant. Audience targeted: ${ageGroup.range}. Slow-to-medium pacing, positive reinforcement, no personalized ad tracking, comments disabled per YouTube Kids policy.",
            createdAt = System.currentTimeMillis()
        )
    }
}
