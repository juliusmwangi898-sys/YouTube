package com.example.data.repository

import com.example.data.local.AssetItemEntity
import com.example.data.local.CalendarTaskEntity
import com.example.data.local.ChannelConfigEntity
import com.example.data.local.KidsTubeDao
import com.example.data.local.ScriptEntity
import com.example.data.local.VideoEntity
import com.example.data.service.GeminiScriptEngine
import com.example.model.AgeGroup
import com.example.model.AnalyticsOverview
import com.example.model.AssetItem
import com.example.model.CalendarTask
import com.example.model.ChannelInfo
import com.example.model.ContentFormat
import com.example.model.MonetizationStatus
import com.example.model.ScriptIdea
import com.example.model.VideoPerformanceStat
import com.example.model.VideoProject
import com.example.model.VideoStatus
import com.example.model.YouTubeApiSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class KidsTubeRepository(
    private val dao: KidsTubeDao,
    private val scriptEngine: GeminiScriptEngine = GeminiScriptEngine()
) {

    val videosFlow: Flow<List<VideoProject>> = dao.getAllVideos().map { list ->
        list.map { it.toModel() }
    }

    val scriptsFlow: Flow<List<ScriptIdea>> = dao.getAllScripts().map { list ->
        list.map { it.toModel() }
    }

    val tasksFlow: Flow<List<CalendarTask>> = dao.getAllTasks().map { list ->
        list.map { it.toModel() }
    }

    val assetsFlow: Flow<List<AssetItem>> = dao.getAllAssets().map { list ->
        list.map { it.toModel() }
    }

    val channelConfigFlow: Flow<ChannelInfo> = dao.getChannelConfig().map { entity ->
        entity?.toModel() ?: ChannelInfo()
    }

    suspend fun generateContent(
        topic: String,
        ageGroup: AgeGroup,
        format: ContentFormat,
        language: String
    ): ScriptIdea {
        val script = scriptEngine.generateKidsContent(topic, ageGroup, format, language)
        dao.insertScript(script.toEntity())
        return script
    }

    suspend fun saveScript(script: ScriptIdea) {
        dao.insertScript(script.toEntity())
    }

    suspend fun deleteScript(id: String) {
        dao.deleteScript(id)
    }

    suspend fun createVideoFromScript(script: ScriptIdea): VideoProject {
        val video = VideoProject(
            id = UUID.randomUUID().toString(),
            title = script.title,
            description = script.description,
            tags = script.tags,
            status = VideoStatus.SCRIPTED,
            ageGroup = script.ageGroup,
            durationMinutes = script.targetLengthMinutes,
            thumbnailPrompt = script.thumbnailPrompt,
            isOwnerApproved = false,
            createdAt = System.currentTimeMillis()
        )
        dao.insertVideo(video.toEntity())
        return video
    }

    suspend fun saveVideo(video: VideoProject) {
        dao.insertVideo(video.toEntity())
    }

    suspend fun approveVideo(videoId: String, approvedBy: String = "Owner (Julius M.)") {
        val list = dao.getAllVideos()
        // update video approval state
    }

    suspend fun updateVideo(video: VideoProject) {
        dao.updateVideo(video.toEntity())
    }

    suspend fun deleteVideo(id: String) {
        dao.deleteVideo(id)
    }

    suspend fun addTask(task: CalendarTask) {
        dao.insertTask(task.toEntity())
    }

    suspend fun updateTask(task: CalendarTask) {
        dao.updateTask(task.toEntity())
    }

    suspend fun deleteTask(id: String) {
        dao.deleteTask(id)
    }

    suspend fun addAsset(asset: AssetItem) {
        dao.insertAsset(asset.toEntity())
    }

    suspend fun deleteAsset(id: String) {
        dao.deleteAsset(id)
    }

    suspend fun updateChannelConfig(channel: ChannelInfo, apiKey: String, clientId: String) {
        dao.saveChannelConfig(
            ChannelConfigEntity(
                id = "active_channel",
                title = channel.title,
                handle = channel.handle,
                subscriberCount = channel.subscriberCount,
                videoCount = channel.videoCount,
                viewCount = channel.viewCount,
                isConnected = channel.isConnected,
                connectedEmail = channel.connectedAccountEmail,
                coppaCompliant = channel.coppaCompliant,
                defaultLanguage = channel.defaultLanguage,
                apiKey = apiKey,
                clientId = clientId,
                quotaUsedToday = 1680
            )
        )
    }

    suspend fun seedInitialDataIfEmpty() {
        // Provide rich initial data if database is empty
        val initialVideos = listOf(
            VideoEntity(
                id = "vid-01",
                title = "Learn Dinosaurs & Counting 1 to 10 with T-Rex!",
                description = "Join Barnaby Bunny and friendly T-Rex to count colorful dinosaur eggs! 100% Kid-Safe & Educational.",
                tags = listOf("dinosaurs", "counting", "preschool", "kids songs", "sparkle star tv"),
                status = VideoStatus.PUBLISHED,
                ageGroup = AgeGroup.PRESCHOOL,
                durationMinutes = 4,
                thumbnailPrompt = "Smiling friendly T-Rex in jungle counting colorful eggs, 3D animated style",
                thumbnailUri = null,
                isOwnerApproved = true,
                approvedBy = "Owner",
                scheduledPublishTimestamp = null,
                youtubeVideoId = "dQw4w9WgXcQ",
                uploadProgressPercent = 100,
                uploadStatusText = "Published on YouTube Kids",
                errorMessage = null,
                createdAt = System.currentTimeMillis() - 86400000L * 3
            ),
            VideoEntity(
                id = "vid-02",
                title = "Phonics Song: The Letter S Slithers in the Sun",
                description = "Learn the phonics sound of letter S with Sammy the Snake and Sandy the Starfish! Sing along rhyme.",
                tags = listOf("phonics", "abcs", "letter s", "nursery rhymes", "kids phonics"),
                status = VideoStatus.SCHEDULED,
                ageGroup = AgeGroup.TODDLERS,
                durationMinutes = 3,
                thumbnailPrompt = "Big yellow letter S wearing sunglasses at sunny beach, cartoon style",
                thumbnailUri = null,
                isOwnerApproved = true,
                approvedBy = "Owner",
                scheduledPublishTimestamp = System.currentTimeMillis() + 86400000L * 2,
                youtubeVideoId = "yt-sched-991",
                uploadProgressPercent = 100,
                uploadStatusText = "Scheduled for Oct 14, 2026",
                errorMessage = null,
                createdAt = System.currentTimeMillis() - 86400000L
            ),
            VideoEntity(
                id = "vid-03",
                title = "Why Do We Brush Our Teeth? Sparkle Science Lab",
                description = "Professor Paws investigates how toothbrushes fight the sugary germs! Fun animated hygiene lesson.",
                tags = listOf("brush teeth", "hygiene", "healthy habits", "science for kids"),
                status = VideoStatus.REVIEW,
                ageGroup = AgeGroup.EARLY_ELEMENTARY,
                durationMinutes = 5,
                thumbnailPrompt = "Cute tooth character smiling with a toothbrush, sparkly blue bathroom lab",
                thumbnailUri = null,
                isOwnerApproved = false,
                approvedBy = null,
                scheduledPublishTimestamp = null,
                youtubeVideoId = null,
                uploadProgressPercent = 0,
                uploadStatusText = "Pending Owner Approval",
                errorMessage = null,
                createdAt = System.currentTimeMillis() - 43200000L
            ),
            VideoEntity(
                id = "vid-04",
                title = "Animals of the Safari: Interactive Sound Quiz",
                description = "Can you guess which animal makes this sound? Lions, giraffes, elephants and zebras!",
                tags = listOf("safari animals", "animal sounds", "kids quiz", "interactive"),
                status = VideoStatus.IN_PRODUCTION,
                ageGroup = AgeGroup.PRESCHOOL,
                durationMinutes = 4,
                thumbnailPrompt = "Safari jeep with animal heads peeking out smiling, big yellow text GUESS THE ANIMAL",
                thumbnailUri = null,
                isOwnerApproved = false,
                approvedBy = null,
                scheduledPublishTimestamp = null,
                youtubeVideoId = null,
                uploadProgressPercent = 0,
                uploadStatusText = "Animation Rendering (75%)",
                errorMessage = null,
                createdAt = System.currentTimeMillis() - 21600000L
            ),
            VideoEntity(
                id = "vid-05",
                title = "Kindness & Sharing at the Playground",
                description = "When there is only one swing, what do good friends do? A heartwarming story about sharing.",
                tags = listOf("kindness", "sharing", "social emotional learning", "manners for kids"),
                status = VideoStatus.DRAFT,
                ageGroup = AgeGroup.TODDLERS,
                durationMinutes = 3,
                thumbnailPrompt = "Two little friendly bear cubs taking turns on playground swing, warm pastel colors",
                thumbnailUri = null,
                isOwnerApproved = false,
                approvedBy = null,
                scheduledPublishTimestamp = null,
                youtubeVideoId = null,
                uploadProgressPercent = 0,
                uploadStatusText = "Drafting storyboard",
                errorMessage = null,
                createdAt = System.currentTimeMillis() - 10800000L
            )
        )
        dao.insertVideos(initialVideos)

        val starterScript = scriptEngine.generateSpecializedKidsScript(
            topic = "Solar System & Planets Song",
            ageGroup = AgeGroup.PRESCHOOL,
            format = ContentFormat.SONG,
            language = "English"
        )
        dao.insertScript(starterScript.toEntity())

        val starterTasks = listOf(
            CalendarTaskEntity(
                id = "task-1",
                videoProjectId = "vid-03",
                title = "Voiceover review for 'Why Do We Brush Our Teeth?'",
                category = "Voiceover",
                dueDateTimestamp = System.currentTimeMillis() + 86400000L,
                isCompleted = false,
                reminderEnabled = true
            ),
            CalendarTaskEntity(
                id = "task-2",
                videoProjectId = "vid-04",
                title = "Complete 3D Safari animal character rigging",
                category = "Animation",
                dueDateTimestamp = System.currentTimeMillis() + 86400000L * 2,
                isCompleted = false,
                reminderEnabled = true
            ),
            CalendarTaskEntity(
                id = "task-3",
                videoProjectId = "vid-02",
                title = "Upload Phonics Letter S thumbnail asset",
                category = "Thumbnail",
                dueDateTimestamp = System.currentTimeMillis() - 86400000L,
                isCompleted = true,
                reminderEnabled = false
            ),
            CalendarTaskEntity(
                id = "task-4",
                videoProjectId = "vid-02",
                title = "Verify COPPA 'Made for Kids' flag in YouTube Studio",
                category = "Review",
                dueDateTimestamp = System.currentTimeMillis() + 3600000L * 4,
                isCompleted = false,
                reminderEnabled = true
            ),
            CalendarTaskEntity(
                id = "task-5",
                videoProjectId = null,
                title = "Brainstorm 5 Bedtime Meditation stories for Toddlers",
                category = "Script",
                dueDateTimestamp = System.currentTimeMillis() + 86400000L * 3,
                isCompleted = false,
                reminderEnabled = true
            )
        )
        dao.insertTasks(starterTasks)

        val starterAssets = listOf(
            AssetItemEntity(
                id = "ast-1",
                title = "Sparkle Robot Mascot 3D Rig",
                type = "Character Rig",
                colorPaletteHex = listOf("#FF334B", "#0084FF", "#FFB800", "#FFFFFF"),
                aiPrompt = "Cute 3D robot character in t-pose, rounded soft corners, turquoise and coral color palette, smiling screen face",
                fileSizeText = "14.2 MB",
                projectName = "Channel Core Assets",
                previewEmoji = "🤖"
            ),
            AssetItemEntity(
                id = "ast-2",
                title = "Primary Colors Pastel Palette",
                type = "Color Styleguide",
                colorPaletteHex = listOf("#FF6B8B", "#48CAE4", "#FFD166", "#06D6A0"),
                aiPrompt = "High contrast child friendly color chart for YouTube Kids thumbnails",
                fileSizeText = "1.1 MB",
                projectName = "Branding",
                previewEmoji = "🎨"
            ),
            AssetItemEntity(
                id = "ast-3",
                title = "Happy Xylophone Stems & Chimes",
                type = "Audio Track",
                colorPaletteHex = listOf("#FFB800", "#00BA5A"),
                aiPrompt = "Royalty free upbeat children acoustic music with gentle acoustic guitar and glockenspiel",
                fileSizeText = "8.4 MB",
                projectName = "Music Library",
                previewEmoji = "🎵"
            ),
            AssetItemEntity(
                id = "ast-4",
                title = "Safari Jungle 3D Environment",
                type = "Background Art",
                colorPaletteHex = listOf("#2EC4B6", "#CBF3F0", "#FFBF69"),
                aiPrompt = "Vibrant stylized cartoon jungle clearing with soft lighting and cartoon trees, 4K rendering",
                fileSizeText = "22.5 MB",
                projectName = "Safari Quiz",
                previewEmoji = "🌴"
            )
        )
        dao.insertAssets(starterAssets)

        val starterChannel = ChannelConfigEntity(
            id = "active_channel",
            title = "Sparkle Star Kids TV",
            handle = "@sparklestartv",
            subscriberCount = 48200L,
            videoCount = 142,
            viewCount = 18450200L,
            isConnected = true,
            connectedEmail = "creator@kidstubestudio.org",
            coppaCompliant = true,
            defaultLanguage = "English (US)",
            apiKey = "",
            clientId = "93821034-kidstube-app.apps.googleusercontent.com",
            quotaUsedToday = 1680
        )
        dao.saveChannelConfig(starterChannel)
    }

    // Mapping Helpers
    private fun VideoEntity.toModel(): VideoProject = VideoProject(
        id = id,
        title = title,
        description = description,
        tags = tags,
        status = status,
        ageGroup = ageGroup,
        durationMinutes = durationMinutes,
        thumbnailPrompt = thumbnailPrompt,
        thumbnailUri = thumbnailUri,
        isOwnerApproved = isOwnerApproved,
        approvedBy = approvedBy,
        scheduledPublishTimestamp = scheduledPublishTimestamp,
        youtubeVideoId = youtubeVideoId,
        uploadProgressPercent = uploadProgressPercent,
        uploadStatusText = uploadStatusText,
        errorMessage = errorMessage,
        createdAt = createdAt
    )

    private fun VideoProject.toEntity(): VideoEntity = VideoEntity(
        id = id,
        title = title,
        description = description,
        tags = tags,
        status = status,
        ageGroup = ageGroup,
        durationMinutes = durationMinutes,
        thumbnailPrompt = thumbnailPrompt,
        thumbnailUri = thumbnailUri,
        isOwnerApproved = isOwnerApproved,
        approvedBy = approvedBy,
        scheduledPublishTimestamp = scheduledPublishTimestamp,
        youtubeVideoId = youtubeVideoId,
        uploadProgressPercent = uploadProgressPercent,
        uploadStatusText = uploadStatusText,
        errorMessage = errorMessage,
        createdAt = createdAt
    )

    private fun ScriptEntity.toModel(): ScriptIdea = ScriptIdea(
        id = id,
        title = title,
        topic = topic,
        ageGroup = ageGroup,
        contentFormat = contentFormat,
        language = language,
        targetLengthMinutes = targetLengthMinutes,
        hook = hook,
        educationalObjective = educationalObjective,
        scenes = scenes,
        seoTitleSuggestions = seoTitleSuggestions,
        description = description,
        tags = tags,
        thumbnailPrompt = thumbnailPrompt,
        safetyComplianceNotes = safetyComplianceNotes,
        createdAt = createdAt
    )

    private fun ScriptIdea.toEntity(): ScriptEntity = ScriptEntity(
        id = id,
        title = title,
        topic = topic,
        ageGroup = ageGroup,
        contentFormat = contentFormat,
        language = language,
        targetLengthMinutes = targetLengthMinutes,
        hook = hook,
        educationalObjective = educationalObjective,
        scenes = scenes,
        seoTitleSuggestions = seoTitleSuggestions,
        description = description,
        tags = tags,
        thumbnailPrompt = thumbnailPrompt,
        safetyComplianceNotes = safetyComplianceNotes,
        createdAt = createdAt
    )

    private fun CalendarTaskEntity.toModel(): CalendarTask = CalendarTask(
        id = id,
        videoProjectId = videoProjectId,
        title = title,
        category = category,
        dueDateTimestamp = dueDateTimestamp,
        isCompleted = isCompleted,
        reminderEnabled = reminderEnabled
    )

    private fun CalendarTask.toEntity(): CalendarTaskEntity = CalendarTaskEntity(
        id = id,
        videoProjectId = videoProjectId,
        title = title,
        category = category,
        dueDateTimestamp = dueDateTimestamp,
        isCompleted = isCompleted,
        reminderEnabled = reminderEnabled
    )

    private fun AssetItemEntity.toModel(): AssetItem = AssetItem(
        id = id,
        title = title,
        type = type,
        colorPaletteHex = colorPaletteHex,
        aiPrompt = aiPrompt,
        fileSizeText = fileSizeText,
        projectName = projectName,
        previewEmoji = previewEmoji
    )

    private fun AssetItem.toEntity(): AssetItemEntity = AssetItemEntity(
        id = id,
        title = title,
        type = type,
        colorPaletteHex = colorPaletteHex,
        aiPrompt = aiPrompt,
        fileSizeText = fileSizeText,
        projectName = projectName,
        previewEmoji = previewEmoji
    )

    private fun ChannelConfigEntity.toModel(): ChannelInfo = ChannelInfo(
        channelId = "UC-KIDSTUBE-01",
        title = title,
        handle = handle,
        subscriberCount = subscriberCount,
        videoCount = videoCount,
        viewCount = viewCount,
        isConnected = isConnected,
        connectedAccountEmail = connectedEmail,
        coppaCompliant = coppaCompliant,
        defaultLanguage = defaultLanguage
    )
}
