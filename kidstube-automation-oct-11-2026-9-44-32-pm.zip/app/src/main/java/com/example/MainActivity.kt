package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppNavTab
import com.example.ui.KidsTubeViewModel
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.AssetManagerScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DeliverablesExportScreen
import com.example.ui.screens.MonetizationScreen
import com.example.ui.screens.ScriptGeneratorScreen
import com.example.ui.screens.VideoManagementScreen
import com.example.ui.screens.YouTubeApiScreen
import com.example.ui.theme.KidsGreen
import com.example.ui.theme.KidsRed
import com.example.ui.theme.KidsYellow
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: KidsTubeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KidsTubeApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KidsTubeApp(viewModel: KidsTubeViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val toastMsg by viewModel.toastMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMsg) {
        toastMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToast()
        }
    }

    // Support back button to return to dashboard
    if (currentTab != AppNavTab.DASHBOARD) {
        BackHandler {
            viewModel.selectTab(AppNavTab.DASHBOARD)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(KidsRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "▶", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "KidsTube",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = " Studio",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 18.sp,
                                    color = KidsRed
                                )
                            }
                            Text(
                                text = "YouTube Kids Channel Automation Bot",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFE2F9EB),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = KidsGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "COPPA Safe",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = KidsGreen
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            ScrollableTabRow(
                selectedTabIndex = currentTab.ordinal,
                edgePadding = 12.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = KidsRed,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("app_navigation_bar")
            ) {
                AppNavTab.values().forEach { tab ->
                    Tab(
                        selected = currentTab == tab,
                        onClick = { viewModel.selectTab(tab) },
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                        text = {
                            Text(
                                text = tab.label,
                                fontSize = 11.sp,
                                fontWeight = if (currentTab == tab) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = getTabIcon(tab),
                                contentDescription = tab.label,
                                modifier = Modifier.size(20.dp),
                                tint = if (currentTab == tab) KidsRed else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppNavTab.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                AppNavTab.GENERATOR -> ScriptGeneratorScreen(viewModel = viewModel)
                AppNavTab.VIDEOS -> VideoManagementScreen(viewModel = viewModel)
                AppNavTab.CALENDAR -> CalendarScreen(viewModel = viewModel)
                AppNavTab.ASSETS -> AssetManagerScreen(viewModel = viewModel)
                AppNavTab.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                AppNavTab.MONETIZATION -> MonetizationScreen(viewModel = viewModel)
                AppNavTab.YOUTUBE_API -> YouTubeApiScreen(viewModel = viewModel)
                AppNavTab.WEB_EXPORT -> DeliverablesExportScreen(viewModel = viewModel)
            }
        }
    }
}

fun getTabIcon(tab: AppNavTab): ImageVector = when (tab) {
    AppNavTab.DASHBOARD -> Icons.Default.Dashboard
    AppNavTab.GENERATOR -> Icons.Default.AutoAwesome
    AppNavTab.VIDEOS -> Icons.Default.VideoLibrary
    AppNavTab.CALENDAR -> Icons.Default.CalendarMonth
    AppNavTab.ASSETS -> Icons.Default.PhotoLibrary
    AppNavTab.ANALYTICS -> Icons.Default.Insights
    AppNavTab.MONETIZATION -> Icons.Default.MonetizationOn
    AppNavTab.YOUTUBE_API -> Icons.Default.Security
    AppNavTab.WEB_EXPORT -> Icons.Default.Code
}
