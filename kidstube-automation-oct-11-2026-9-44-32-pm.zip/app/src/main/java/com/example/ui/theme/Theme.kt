package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = KidsRed,
    onPrimary = Color.White,
    primaryContainer = KidsRedDark,
    onPrimaryContainer = Color.White,
    secondary = KidsBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF003875),
    onSecondaryContainer = Color.White,
    tertiary = KidsYellow,
    onTertiary = DarkGray,
    background = DarkBackground,
    onBackground = Color(0xFFF1F5F9),
    surface = DarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = DarkCardSurface,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = DarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = KidsRed,
    onPrimary = Color.White,
    primaryContainer = KidsRedContainer,
    onPrimaryContainer = KidsRedDark,
    secondary = KidsBlue,
    onSecondary = Color.White,
    secondaryContainer = KidsBlueContainer,
    onSecondaryContainer = Color(0xFF004488),
    tertiary = KidsYellow,
    onTertiary = DarkGray,
    tertiaryContainer = KidsYellowContainer,
    background = BackgroundLight,
    onBackground = DarkGray,
    surface = CardSurface,
    onSurface = DarkGray,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = MediumGray,
    outline = BorderGray
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our brand colors for cohesive Kids Studio experience
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
