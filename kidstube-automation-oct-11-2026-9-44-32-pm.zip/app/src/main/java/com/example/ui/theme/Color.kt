package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// KidsTube Studio Brand Colors - Playful, vibrant, and modern
val KidsRed = Color(0xFFFF334B)
val KidsRedDark = Color(0xFFD61830)
val KidsRedContainer = Color(0xFFFFECEE)

val KidsBlue = Color(0xFF0084FF)
val KidsBlueContainer = Color(0xFFE5F2FF)

val KidsYellow = Color(0xFFFFB800)
val KidsYellowContainer = Color(0xFFFFF7DB)

val KidsGreen = Color(0xFF00BA5A)
val KidsGreenContainer = Color(0xFFE2F9EB)

val KidsPurple = Color(0xFF7928CA)
val KidsPurpleContainer = Color(0xFFF3E8FF)

// Neutrals
val DarkGray = Color(0xFF1E2129)
val MediumGray = Color(0xFF6B7280)
val LightGray = Color(0xFFF3F4F6)
val BorderGray = Color(0xFFE5E7EB)
val CardSurface = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF8FAFC)

// Dark theme colors
val DarkBackground = Color(0xFF0F1117)
val DarkSurface = Color(0xFF181B23)
val DarkCardSurface = Color(0xFF222631)
val DarkBorder = Color(0xFF2E3442)
