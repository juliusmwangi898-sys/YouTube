package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.KidsTubeViewModel
import com.example.ui.theme.KidsBlue
import com.example.ui.theme.KidsGreen
import com.example.ui.theme.KidsPurple
import com.example.ui.theme.KidsRed
import com.example.ui.theme.KidsYellow

@Composable
fun MonetizationScreen(viewModel: KidsTubeViewModel) {
    val monetization by viewModel.monetization.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("monetization_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(KidsYellow),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.MonetizationOn, contentDescription = null, tint = Color.Black)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "💰 Monetization & YPP Eligibility",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Track YouTube Partner Program progress, revenue, & ROI",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // MANDATORY LEGAL DISCLAIMER (Prompt Rule #10)
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFFFF9E6),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Policy,
                        contentDescription = null,
                        tint = Color(0xFFB78103),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Important Policy Notice: Revenue figures are estimates and not a guarantee of income. Eligibility and actual earnings depend strictly on official YouTube Partner Program policies, COPPA compliance, and channel review.",
                        fontSize = 11.sp,
                        color = Color(0xFF7A5700),
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // YouTube Partner Program (YPP) Status Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🎯 YPP Eligibility Status", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = KidsGreen.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = KidsGreen, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Eligible & Active", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = KidsGreen)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress 1: Subscribers
                    YppProgressRow(
                        title = "Subscribers (Threshold: 1,000)",
                        currentText = "${monetization.subscriberCount.toInt()} / 1,000",
                        progress = monetization.subProgressRatio,
                        color = KidsBlue,
                        isComplete = monetization.subscriberCount >= 1000
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Progress 2: Watch Hours
                    YppProgressRow(
                        title = "Public Watch Hours (Threshold: 4,000 hrs)",
                        currentText = "${monetization.watchHours.toInt()} / 4,000 hrs",
                        progress = monetization.watchHoursProgressRatio,
                        color = KidsRed,
                        isComplete = monetization.watchHours >= 4000
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Progress 3: Shorts Views alternative
                    YppProgressRow(
                        title = "Or Shorts Views (Threshold: 10 Million)",
                        currentText = "${monetization.shortsViews / 1000000}M / 10M",
                        progress = monetization.shortsProgressRatio,
                        color = KidsYellow,
                        isComplete = monetization.shortsViews >= 10000000
                    )
                }
            }
        }

        // Financial Tracker & Net ROI
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.TrendingUp, contentDescription = null, tint = KidsGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Monthly Financials & Net ROI", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FinancialPill(
                            title = "Est. Gross Revenue",
                            amount = "$${String.format("%.2f", monetization.estimatedMonthlyRevenue)}",
                            color = KidsGreen
                        )
                        FinancialPill(
                            title = "Production Costs",
                            amount = "$${String.format("%.2f", monetization.productionExpenses)}",
                            color = KidsRed
                        )
                        FinancialPill(
                            title = "Net Profit",
                            amount = "+$${String.format("%.2f", monetization.netMonthlyProfit)}",
                            color = KidsBlue
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Expense Breakdown:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "• Voice Actor & Sound FX licenses: $350/mo", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "• AI Cloud Rendering & Animation tools: $400/mo", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "• Channel administration & backup: $200/mo", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        // Kids Monetization Rules & COPPA Constraints
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "👶 Kids Channel Monetization Rules (COPPA)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Contextual Non-Personalized Ads: ACTIVE (Standard for Made for Kids).\n" +
                               "• Personalized Retargeting Ads: DISABLED by YouTube policy.\n" +
                               "• Merch Shelf & Official Channel Store: ELIGIBLE.\n" +
                               "• Super Chat / Channel Memberships: LIMITED per YouTube Kids safety protocols.\n" +
                               "• Direct Brand Sponsorships: Allowed with explicit paid promotion disclosure.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun YppProgressRow(
    title: String,
    currentText: String,
    progress: Float,
    color: Color,
    isComplete: Boolean
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(
                text = currentText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isComplete) KidsGreen else color
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = if (isComplete) KidsGreen else color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
fun FinancialPill(title: String, amount: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = amount, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = color)
    }
}
