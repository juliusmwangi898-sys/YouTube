package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.KidsTubeDatabase
import com.example.data.repository.KidsTubeRepository
import com.example.model.AgeGroup
import com.example.model.AnalyticsOverview
import com.example.model.AssetItem
import com.example.model.CalendarTask
import com.example.model.ChannelInfo
import com.example.model.ContentFormat
import com.example.model.MonetizationStatus
import com.example.model.ScriptIdea
import com.example.model.VideoPerformanceStat
import com.example.model.VideoProject
import com.example.model.VideoStatus
import com.example.model.YouTubeApiSettings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppNavTab(val label: String, val iconName: String) {
    DASHBOARD("Dashboard", "dashboard"),
    GENERATOR("AI Generator", "auto_awesome"),
    VIDEOS("Videos", "video_library"),
    CALENDAR("Calendar", "calendar_month"),
    ASSETS("Thumbnails & Assets", "photo_library"),
    ANALYTICS("Analytics", "insights"),
    MONETIZATION("Monetization", "monetization_on"),
    YOUTUBE_API("YouTube API", "api"),
    WEB_EXPORT("Export Web/Java", "code")
}

class KidsTubeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: KidsTubeRepository

    init {
        val db = KidsTubeDatabase.getDatabase(application)
        repository = KidsTubeRepository(db.kidsTubeDao())
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    val videos: StateFlow<List<VideoProject>> = repository.videosFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scripts: StateFlow<List<ScriptIdea>> = repository.scriptsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasks: StateFlow<List<CalendarTask>> = repository.tasksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val assets: StateFlow<List<AssetItem>> = repository.assetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val channelInfo: StateFlow<ChannelInfo> = repository.channelConfigFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChannelInfo())

    private val _currentTab = MutableStateFlow(AppNavTab.DASHBOARD)
    val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

    private val _isGeneratingScript = MutableStateFlow(false)
    val isGeneratingScript: StateFlow<Boolean> = _isGeneratingScript.asStateFlow()

    private val _activeScript = MutableStateFlow<ScriptIdea?>(null)
    val activeScript: StateFlow<ScriptIdea?> = _activeScript.asStateFlow()

    private val _selectedVideo = MutableStateFlow<VideoProject?>(null)
    val selectedVideo: StateFlow<VideoProject?> = _selectedVideo.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _analytics = MutableStateFlow(
        AnalyticsOverview(
            totalViews = 18450200L,
            viewsChangePercent = 14.8,
            totalWatchHours = 520400L,
            subscribersTotal = 48200L,
            subscribersGained = 2450L,
            avgRetentionRate = 68.4,
            clickThroughRate = 11.2,
            uploadFrequencyPerWeek = 3.5,
            isRealApiConnected = true,
            topVideos = listOf(
                VideoPerformanceStat(
                    videoId = "v1",
                    title = "Learn Dinosaurs & Counting 1 to 10!",
                    views = 1240000L,
                    likes = 48200L,
                    watchTimeHours = 38400.0,
                    publishedDaysAgo = 14,
                    thumbnailColorHex = 0xFFFF334B
                ),
                VideoPerformanceStat(
                    videoId = "v2",
                    title = "Phonics Song: ABCs with Sammy the Star",
                    views = 890000L,
                    likes = 32100L,
                    watchTimeHours = 26500.0,
                    publishedDaysAgo = 28,
                    thumbnailColorHex = 0xFF0084FF
                ),
                VideoPerformanceStat(
                    videoId = "v3",
                    title = "Colors & Shapes Safari Adventure",
                    views = 640000L,
                    likes = 21900L,
                    watchTimeHours = 19400.0,
                    publishedDaysAgo = 45,
                    thumbnailColorHex = 0xFFFFB800
                ),
                VideoPerformanceStat(
                    videoId = "v4",
                    title = "Bedtime Lullaby for Sleepy Little Bears",
                    views = 510000L,
                    likes = 18400L,
                    watchTimeHours = 31200.0,
                    publishedDaysAgo = 60,
                    thumbnailColorHex = 0xFF7928CA
                )
            )
        )
    )
    val analytics: StateFlow<AnalyticsOverview> = _analytics.asStateFlow()

    private val _monetization = MutableStateFlow(MonetizationStatus())
    val monetization: StateFlow<MonetizationStatus> = _monetization.asStateFlow()

    private val _apiSettings = MutableStateFlow(YouTubeApiSettings())
    val apiSettings: StateFlow<YouTubeApiSettings> = _apiSettings.asStateFlow()

    fun selectTab(tab: AppNavTab) {
        _currentTab.value = tab
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun selectVideo(video: VideoProject?) {
        _selectedVideo.value = video
    }

    fun generateKidsContent(
        topic: String,
        ageGroup: AgeGroup,
        format: ContentFormat,
        language: String
    ) {
        viewModelScope.launch {
            _isGeneratingScript.value = true
            try {
                val script = repository.generateContent(topic, ageGroup, format, language)
                _activeScript.value = script
                showToast("✨ Generated: ${script.title}")
            } catch (e: Exception) {
                showToast("Error generating: ${e.message}")
            } finally {
                _isGeneratingScript.value = false
            }
        }
    }

    fun createVideoFromActiveScript() {
        val script = _activeScript.value ?: return
        viewModelScope.launch {
            val video = repository.createVideoFromScript(script)
            showToast("🎬 Project created: ${video.title}")
            _currentTab.value = AppNavTab.VIDEOS
            _selectedVideo.value = video
        }
    }

    fun toggleOwnerApproval(video: VideoProject) {
        val updated = video.copy(
            isOwnerApproved = !video.isOwnerApproved,
            approvedBy = if (!video.isOwnerApproved) "Channel Owner (Signed)" else null,
            status = if (!video.isOwnerApproved) VideoStatus.APPROVED else VideoStatus.REVIEW
        )
        viewModelScope.launch {
            repository.updateVideo(updated)
            _selectedVideo.value = updated
            if (updated.isOwnerApproved) {
                showToast("✅ Video explicitly approved by channel owner!")
            } else {
                showToast("ℹ️ Approval revoked. Video requires review.")
            }
        }
    }

    fun updateVideoDetails(
        video: VideoProject,
        title: String,
        description: String,
        tags: List<String>,
        status: VideoStatus,
        ageGroup: AgeGroup
    ) {
        val updated = video.copy(
            title = title,
            description = description,
            tags = tags,
            status = status,
            ageGroup = ageGroup
        )
        viewModelScope.launch {
            repository.updateVideo(updated)
            _selectedVideo.value = updated
            showToast("Saved video changes")
        }
    }

    fun scheduleOrPublishVideo(video: VideoProject, scheduleTime: Long? = null) {
        if (!video.isOwnerApproved) {
            showToast("⚠️ Action Blocked: YouTube Kids policy requires explicit Owner Approval before publish!")
            return
        }

        viewModelScope.launch {
            if (scheduleTime != null) {
                val updated = video.copy(
                    status = VideoStatus.SCHEDULED,
                    scheduledPublishTimestamp = scheduleTime,
                    uploadProgressPercent = 100,
                    uploadStatusText = "Scheduled for publish"
                )
                repository.updateVideo(updated)
                _selectedVideo.value = updated
                showToast("📅 Video scheduled successfully!")
            } else {
                // Simulate publishing pipeline through official YouTube Data API v3
                _selectedVideo.value = video.copy(
                    uploadProgressPercent = 30,
                    uploadStatusText = "Encoding 1080p60 & checking Made for Kids..."
                )
                delay(1200)
                _selectedVideo.value = video.copy(
                    uploadProgressPercent = 80,
                    uploadStatusText = "Uploading to YouTube Data API v3..."
                )
                delay(1000)
                val published = video.copy(
                    status = VideoStatus.PUBLISHED,
                    youtubeVideoId = "yt-" + UUID.randomUUID().toString().take(8),
                    uploadProgressPercent = 100,
                    uploadStatusText = "Published to YouTube Kids",
                    errorMessage = null
                )
                repository.updateVideo(published)
                _selectedVideo.value = published
                showToast("🎉 Video successfully published to YouTube Kids!")
            }
        }
    }

    fun toggleTaskCompletion(task: CalendarTask) {
        val updated = task.copy(isCompleted = !task.isCompleted)
        viewModelScope.launch {
            repository.updateTask(updated)
        }
    }

    fun addNewTask(title: String, category: String, dueTimestamp: Long) {
        val task = CalendarTask(
            id = UUID.randomUUID().toString(),
            title = title,
            category = category,
            dueDateTimestamp = dueTimestamp,
            isCompleted = false,
            reminderEnabled = true
        )
        viewModelScope.launch {
            repository.addTask(task)
            showToast("Added task: $title")
        }
    }

    fun deleteCalendarTask(task: CalendarTask) {
        viewModelScope.launch {
            repository.deleteTask(task.id)
            showToast("Task deleted")
        }
    }

    fun addNewAsset(
        title: String,
        type: String,
        aiPrompt: String,
        palette: List<String>,
        projectName: String
    ) {
        val asset = AssetItem(
            id = UUID.randomUUID().toString(),
            title = title,
            type = type,
            colorPaletteHex = palette,
            aiPrompt = aiPrompt,
            fileSizeText = "4.5 MB",
            projectName = projectName,
            previewEmoji = when (type) {
                "Thumbnail Concept" -> "🖼️"
                "Audio Track" -> "🎵"
                "Character Rig" -> "🤖"
                else -> "🎨"
            }
        )
        viewModelScope.launch {
            repository.addAsset(asset)
            showToast("Asset saved: $title")
        }
    }

    fun deleteAsset(asset: AssetItem) {
        viewModelScope.launch {
            repository.deleteAsset(asset.id)
            showToast("Asset deleted")
        }
    }

    fun toggleYouTubeConnection() {
        val current = _apiSettings.value
        val newState = !current.isConnected
        _apiSettings.value = current.copy(isConnected = newState)
        if (newState) {
            showToast("🔗 Connected to YouTube channel")
        } else {
            showToast("🔌 Disconnected from YouTube account. Session wiped.")
        }
    }

    fun saveApiCredentials(clientId: String, apiKey: String) {
        _apiSettings.value = _apiSettings.value.copy(
            clientId = clientId,
            apiKey = apiKey,
            isConnected = true
        )
        showToast("Saved YouTube API credentials")
    }
}
