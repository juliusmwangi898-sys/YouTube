package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.KidsTubeViewModel
import com.example.ui.theme.KidsBlue
import com.example.ui.theme.KidsGreen
import com.example.ui.theme.KidsPurple
import com.example.ui.theme.KidsRed
import com.example.ui.theme.KidsYellow

@Composable
fun DeliverablesExportScreen(viewModel: KidsTubeViewModel) {
    var selectedFileIndex by remember { mutableStateOf(0) }

    val fileSnippets = listOf(
        "pom.xml (Spring Boot Maven)" to """
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.3</version>
    </parent>
    <groupId>com.kidstube</groupId>
    <artifactId>automation-bot</artifactId>
    <version>1.0.0</version>
    <name>YouTube Kids Channel Automation Bot</name>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-oauth2-client</artifactId>
        </dependency>
        <dependency>
            <groupId>com.google.apis</groupId>
            <artifactId>google-api-services-youtube</artifactId>
            <version>v3-rev20231011-2.0.0</version>
        </dependency>
        <dependency>
            <groupId>com.h2database</groupId>
            <artifactId>h2</artifactId>
            <scope>runtime</scope>
        </dependency>
    </dependencies>
</project>
        """.trimIndent(),

        "YouTubeApiController.java" to """
package com.kidstube.automation.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/youtube")
public class YouTubeApiController {

    @GetMapping("/channel")
    public ResponseEntity<Map<String, Object>> getChannelInfo() {
        return ResponseEntity.ok(Map.of(
            "channelId", "UC-KIDSTUBE-01",
            "title", "Sparkle Star Kids TV",
            "subscribers", 48200,
            "views", 18450200,
            "coppaCompliant", true
        ));
    }

    @PostMapping("/video/approve")
    public ResponseEntity<Map<String, String>> approveVideo(@RequestBody Map<String, String> payload) {
        String videoId = payload.get("videoId");
        // Mandate: Owner must explicitly approve before upload!
        return ResponseEntity.ok(Map.of("status", "APPROVED", "videoId", videoId));
    }
}
        """.trimIndent(),

        "application.yml" to """
server:
  port: 8080

spring:
  application:
    name: kidstube-automation-bot
  datasource:
    url: jdbc:h2:mem:kidstubedb
    driverClassName: org.h2.Driver
    username: sa
    password: 
  security:
    oauth2:
      client:
        registration:
          google:
            client-id: ${'$'}{GOOGLE_CLIENT_ID}
            client-secret: ${'$'}{GOOGLE_CLIENT_SECRET}
            scope:
              - https://www.googleapis.com/auth/youtube.upload
              - https://www.googleapis.com/auth/youtube.readonly
        """.trimIndent(),

        "index.html (Web Frontend)" to """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>KidsTube Automation Bot</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dashboard-wrapper">
    <nav class="sidebar">
      <h2>⭐ KidsTube</h2>
      <ul>
        <li><a href="#dashboard" class="active">Dashboard</a></li>
        <li><a href="#scripts">AI Script Generator</a></li>
        <li><a href="#videos">Video Pipeline</a></li>
        <li><a href="#calendar">Content Calendar</a></li>
        <li><a href="#monetization">Monetization</a></li>
      </ul>
    </nav>
    <main class="content-area">
      <!-- Reactive sections with vanilla JS & REST endpoints -->
    </main>
  </div>
  <script src="app.js"></script>
</body>
</html>
        """.trimIndent()
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("deliverables_export_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(KidsBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "📦 Fullstack Spring Boot & Web Deliverables",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Standalone Maven + Java + HTML5/CSS3/JS source files",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Package Overview
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Terminal, contentDescription = null, tint = KidsGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "How to Run the Web Backend Locally", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF1E2129),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "# 1. Set environment variables:\nexport GOOGLE_CLIENT_ID=\"your-client-id\"\nexport GOOGLE_CLIENT_SECRET=\"your-client-secret\"\n\n# 2. Run with Maven:\n./mvnw spring-boot:run\n\n# 3. Access in browser:\nhttp://localhost:8080",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = Color(0xFF68D391),
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }

        // File Selector Tabs
        item {
            Text(text = "Source Code File Inspector:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                fileSnippets.forEachIndexed { index, pair ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedFileIndex == index) KidsBlue else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                    ) {
                        Button(
                            onClick = { selectedFileIndex = index },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedFileIndex == index) KidsBlue else Color.Transparent,
                                contentColor = if (selectedFileIndex == index) Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                        ) {
                            Text(
                                text = pair.first.takeWhile { it != ' ' },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Code Viewer Box
        item {
            val currentFile = fileSnippets[selectedFileIndex]
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF181B23))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currentFile.first,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFF90CDF4)
                        )
                        IconButton(
                            onClick = { viewModel.showToast("Copied ${currentFile.first} to clipboard!") },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = currentFile.second,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = Color(0xFFE2E8F0),
                        lineHeight = 15.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
