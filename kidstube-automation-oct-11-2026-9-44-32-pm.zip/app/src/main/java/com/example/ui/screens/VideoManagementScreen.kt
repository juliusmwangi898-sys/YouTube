package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AgeGroup
import com.example.model.VideoProject
import com.example.model.VideoStatus
import com.example.ui.KidsTubeViewModel
import com.example.ui.theme.KidsBlue
import com.example.ui.theme.KidsGreen
import com.example.ui.theme.KidsPurple
import com.example.ui.theme.KidsRed
import com.example.ui.theme.KidsYellow

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoManagementScreen(viewModel: KidsTubeViewModel) {
    val videos by viewModel.videos.collectAsState()
    val selectedVideo by viewModel.selectedVideo.collectAsState()
    var filterStatus by remember { mutableStateOf<VideoStatus?>(null) }
    var isEditingDetails by remember { mutableStateOf(false) }

    val filteredVideos = if (filterStatus == null) videos else videos.filter { it.status == filterStatus }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("video_management_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "📹 Video Management & Pipeline",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Owner approval gate before YouTube Kids publication",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = filterStatus == null,
                    onClick = { filterStatus = null },
                    label = { Text("All (${videos.size})", fontSize = 12.sp) }
                )
                VideoStatus.values().forEach { st ->
                    val count = videos.count { it.status == st }
                    FilterChip(
                        selected = filterStatus == st,
                        onClick = { filterStatus = st },
                        label = { Text("${st.label} ($count)", fontSize = 12.sp) }
                    )
                }
            }
        }

        // Active/Selected Video Focus Card
        if (selectedVideo != null) {
            val video = selectedVideo!!
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("selected_video_focus_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Selected Video Project",
                                style = MaterialTheme.typography.labelMedium,
                                color = KidsBlue,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StatusBadge(status = video.status)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "✕",
                                    modifier = Modifier
                                        .clickable { viewModel.selectVideo(null) }
                                        .padding(4.dp),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = video.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = video.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // OWNER APPROVAL COMPLIANCE BANNER (Strict Requirement)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (video.isOwnerApproved) Color(0xFFE2F9EB) else Color(0xFFFFF8E1),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (video.isOwnerApproved) Icons.Default.CheckCircle else Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (video.isOwnerApproved) KidsGreen else Color(0xFFB78103),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (video.isOwnerApproved) "Owner Approved for Publication" else "Explicit Owner Approval Required",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (video.isOwnerApproved) KidsGreen else Color(0xFF856404)
                                    )
                                    Text(
                                        text = if (video.isOwnerApproved)
                                            "Approved by: ${video.approvedBy ?: "Channel Owner"}. Ready for scheduling."
                                        else
                                            "YouTube Kids policy requires channel owner sign-off before upload.",
                                        fontSize = 11.sp,
                                        color = if (video.isOwnerApproved) Color(0xFF1B5E20) else Color(0xFF856404)
                                    )
                                }

                                Button(
                                    onClick = { viewModel.toggleOwnerApproval(video) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (video.isOwnerApproved) Color(0xFFD32F2F) else KidsGreen
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("toggle_owner_approval_button")
                                ) {
                                    Text(
                                        text = if (video.isOwnerApproved) "Revoke" else "Approve",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        if (video.uploadProgressPercent > 0 && video.uploadProgressPercent < 100) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(text = video.uploadStatusText, fontSize = 12.sp, color = KidsBlue)
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { video.uploadProgressPercent / 100f },
                                modifier = Modifier.fillMaxWidth(),
                                color = KidsBlue
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { isEditingDetails = true },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Edit Meta", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    val nextWeek = System.currentTimeMillis() + 86400000L * 3
                                    viewModel.scheduleOrPublishVideo(video, nextWeek)
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = KidsYellow),
                                shape = RoundedCornerShape(10.dp),
                                enabled = video.isOwnerApproved && video.status != VideoStatus.PUBLISHED
                            ) {
                                Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Black)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Schedule", fontSize = 12.sp, color = Color.Black)
                            }

                            Button(
                                onClick = { viewModel.scheduleOrPublishVideo(video, null) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("publish_video_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = KidsRed),
                                shape = RoundedCornerShape(10.dp),
                                enabled = video.isOwnerApproved && video.status != VideoStatus.PUBLISHED
                            ) {
                                Icon(Icons.Default.Publish, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Publish", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // List of all videos
        items(filteredVideos) { video ->
            VideoItemCard(
                video = video,
                onClick = { viewModel.selectVideo(video) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Edit Video Metadata Dialog
    if (isEditingDetails && selectedVideo != null) {
        val video = selectedVideo!!
        var editTitle by remember { mutableStateOf(video.title) }
        var editDesc by remember { mutableStateOf(video.description) }
        var editTagsStr by remember { mutableStateOf(video.tags.joinToString(", ")) }

        AlertDialog(
            onDismissRequest = { isEditingDetails = false },
            title = { Text("Edit Video Metadata") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("Title") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editDesc,
                        onValueChange = { editDesc = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                    OutlinedTextField(
                        value = editTagsStr,
                        onValueChange = { editTagsStr = it },
                        label = { Text("Tags (comma separated)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val tagsList = editTagsStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                        viewModel.updateVideoDetails(
                            video = video,
                            title = editTitle,
                            description = editDesc,
                            tags = tagsList,
                            status = video.status,
                            ageGroup = video.ageGroup
                        )
                        isEditingDetails = false
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { isEditingDetails = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun VideoItemCard(video: VideoProject, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("video_card_${video.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        when (video.status) {
                            VideoStatus.PUBLISHED -> KidsGreen
                            VideoStatus.SCHEDULED -> KidsYellow
                            VideoStatus.APPROVED -> KidsBlue
                            else -> KidsRed
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.OndemandVideo,
                    contentDescription = null,
                    tint = Color.White
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = video.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatusBadge(status = video.status)
                    Text(
                        text = "• ${video.ageGroup.label} • ${video.durationMinutes}m",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Owner approval icon badge
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(
                        if (video.isOwnerApproved) KidsGreen.copy(alpha = 0.15f) else Color(0xFFFFECEE)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (video.isOwnerApproved) Icons.Default.Lock else Icons.Default.LockOpen,
                    contentDescription = null,
                    tint = if (video.isOwnerApproved) KidsGreen else KidsRed,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun StatusBadge(status: VideoStatus) {
    val (bg, fg) = when (status) {
        VideoStatus.PUBLISHED -> KidsGreen.copy(alpha = 0.15f) to KidsGreen
        VideoStatus.SCHEDULED -> KidsYellow.copy(alpha = 0.2f) to Color(0xFF856404)
        VideoStatus.APPROVED -> KidsBlue.copy(alpha = 0.15f) to KidsBlue
        VideoStatus.REVIEW -> Color(0xFFFFF3CD) to Color(0xFF856404)
        VideoStatus.IN_PRODUCTION -> KidsPurple.copy(alpha = 0.15f) to KidsPurple
        else -> Color(0xFFE5E7EB) to Color(0xFF4B5563)
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bg
    ) {
        Text(
            text = status.label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
